//
//  RKTwitterAppDelegate.h
//  RKTwitter
//
//  Created by Blake Watters on 9/5/10.
//  Copyright Two Toasters 2010. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RKTwitterAppDelegate : NSObject <UIApplicationDelegate> {
}

@end

