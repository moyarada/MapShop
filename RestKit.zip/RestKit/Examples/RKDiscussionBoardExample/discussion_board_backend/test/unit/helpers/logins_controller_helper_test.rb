require 'test_helper'

class LoginsControllerHelperTest < ActionView::TestCase
end
