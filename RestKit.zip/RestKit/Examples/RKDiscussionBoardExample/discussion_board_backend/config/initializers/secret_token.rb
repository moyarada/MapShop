# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DiscussionBoardBackend::Application.config.secret_token = '616d0e680e77902eb11864b67ca2d0dc1d521a3801fbb30f46de4bcd5598423142000c31f470f1e35335b692e0a971c754c98ee153ed323f516c190eff38dae4'
