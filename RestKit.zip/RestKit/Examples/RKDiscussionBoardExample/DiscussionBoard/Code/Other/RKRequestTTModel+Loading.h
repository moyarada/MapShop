//
//  RKRequestTTModel+Loading.h
//  DiscussionBoard
//
//  Created by Jeremy Ellison on 1/12/11.
//  Copyright 2011 Two Toasters. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RestKit/Three20/Three20.h>

@interface RKRequestTTModel (Loading)

@end
