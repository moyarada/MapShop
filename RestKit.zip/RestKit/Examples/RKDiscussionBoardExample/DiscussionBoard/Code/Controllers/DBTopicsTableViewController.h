//
//  DBTopicsTableViewController.h
//  DiscussionBoard
//
//  Created by Jeremy Ellison on 1/7/11.
//  Copyright 2011 Two Toasters. All rights reserved.
//

#import "DBResourceListTableViewController.h"

@interface DBTopicsTableViewController : DBResourceListTableViewController {

}

@end
