RestKit Credits
===============

RestKit was originally developed in the summer of 2009 under the name OTRestFramework
as a Ruby on Rails specific object mapper for XML data. In early 2010 the framework was
rebranded as RestKit and evolved into a general purpose HTTP toolkit and object mapping
system.

RestKit is a production of Two Toasters and available as an Open Source package under
the terms of the Apache License (see LICENSE for details).

Original Author
---------------
* Blake Watters   github.com/blakewatters @blakewatters

Core Team
---------
* Jeremy Ellison
* Daniel Hammond
* Jeff Arena

Web Designer
------------
* Adit Shukla

Contributors
------------
* Marc Weil
* Pat Shields
* Tim Kerchmar
* Rachit Shukla
