//
//  RKCat.m
//  RestKit
//
//  Created by Jeremy Ellison on 1/14/10.
//  Copyright 2010 Two Toasters. All rights reserved.
//

#import "RKCat.h"


@implementation RKCat

@dynamic age;
@dynamic birthYear;
@dynamic color;
@dynamic createdAt;
@dynamic humanId;
@dynamic name;
@dynamic nickName;
@dynamic railsID;
@dynamic sex;
@dynamic updatedAt;

@dynamic human;

@end
