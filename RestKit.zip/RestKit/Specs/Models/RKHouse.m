//
//  RKHouse.m
//  RestKit
//
//  Created by Jeremy Ellison on 1/14/10.
//  Copyright 2010 Two Toasters. All rights reserved.
//

#import "RKHouse.h"


@implementation RKHouse

@dynamic city;
@dynamic createdAt;
@dynamic ownerId;
@dynamic railsID;
@dynamic state;
@dynamic street;
@dynamic updatedAt;
@dynamic zip;


@end
