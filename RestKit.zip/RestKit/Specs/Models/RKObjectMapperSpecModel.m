//
//  RKObjectMapperSpecModel.m
//  RestKit
//
//  Created by Blake Watters on 2/18/10.
//  Copyright 2010 Two Toasters. All rights reserved.
//

#import "RKObjectMapperSpecModel.h"

@implementation RKObjectMapperSpecModel

@synthesize name = _name;
@synthesize age = _age;
@synthesize createdAt = _createdAt;

@end
