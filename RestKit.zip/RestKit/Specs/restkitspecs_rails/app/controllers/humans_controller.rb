class HumansController < ResourceController::Base
end
