class ResidentsController < ResourceController::Base
  belongs_to :house
end
