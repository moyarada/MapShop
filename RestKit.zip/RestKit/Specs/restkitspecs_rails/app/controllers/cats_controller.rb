class CatsController < ResourceController::Base
end
