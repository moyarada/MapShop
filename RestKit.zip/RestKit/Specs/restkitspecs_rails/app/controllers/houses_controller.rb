class HousesController < ResourceController::Base
end
