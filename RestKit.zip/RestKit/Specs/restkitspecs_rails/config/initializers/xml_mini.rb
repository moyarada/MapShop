# Set XmlMini backend to Nokogiri
ActiveSupport::XmlMini.backend = 'Nokogiri'
