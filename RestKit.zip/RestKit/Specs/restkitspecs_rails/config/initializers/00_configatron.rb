# Set global configatron options here
# For more info see: http://github.com/markbates/configatron/tree/master
# configatron.some_setting = 'some_value'
