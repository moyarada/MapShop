//
//  Three20.h
//  RestKit
//
//  Created by Blake Watters on 7/9/10.
//  Copyright 2010 Two Toasters. All rights reserved.
//

#import "RKRequestTTModel.h"
#import "RKRequestFilterableTTModel.h"
