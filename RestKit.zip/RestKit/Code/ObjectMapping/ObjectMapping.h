//
//  ObjectMapping.h
//  RestKit
//
//  Created by Blake Watters on 9/30/10.
//  Copyright 2010 Two Toasters. All rights reserved.
//

#import "RKObjectManager.h"
#import "RKObject.h"
#import "RKObjectLoader.h"
