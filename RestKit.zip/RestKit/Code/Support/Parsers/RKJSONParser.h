//
//  RKMappingFormatJSONParser.h
//  RestKit
//
//  Created by Blake Watters on 3/4/10.
//  Copyright 2010 Two Toasters. All rights reserved.
//

#import "RKParser.h"

@interface RKJSONParser : NSObject <RKParser> {
}

@end
